Proyecto de prueba para REV (formato rev-project v1). Ver docs/FORMATO.md en el repositorio.
